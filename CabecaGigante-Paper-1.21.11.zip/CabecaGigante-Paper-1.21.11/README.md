# CabecaGigante — Paper 1.21.11

Plugin para Minecraft Java 1.21.11 (Paper) que mostra uma cabeça de jogador dropada com um modelo visual ampliado em 3x.

## Como funciona

- Detecta itens dropados do tipo `PLAYER_HEAD`.
- Cria um `ItemDisplay` ampliado e acompanha a posição do item original.
- **Não substitui nem remove o item original**: a cabeça continua existindo no chão para que o plugin de loot atual possa continuar identificando-a.
- Remove o modelo visual quando a cabeça é recolhida, some ou é fundida com outro item.
- Outros itens não são ampliados.

## Instalação

1. Compile o projeto com Java 21 e Maven: `mvn clean package`
2. Copie `target/CabecaGigante-1.21.11.jar` para a pasta `plugins` do servidor Paper.
3. Reinicie o servidor.
4. O tamanho pode ser ajustado em `plugins/CabecaGigante/config.yml` (opção `scale`, padrão `3.0`).

## Observação importante sobre compatibilidade

Como o plugin de loot existente não foi fornecido, este plugin preserva a entidade de item original e coloca o modelo grande sobre ela. A cabeça original pode ainda ficar parcialmente visível por baixo/ao redor do modelo, dependendo do ângulo e da versão do cliente. Isso evita remover a entidade que o outro plugin pode usar para reconhecer o clique direito, mas a compatibilidade exata precisa ser testada no servidor com o plugin de loot instalado.
