package br.com.cabecagigante;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Item;
import org.bukkit.entity.ItemDisplay;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityPickupItemEvent;
import org.bukkit.event.entity.ItemDespawnEvent;
import org.bukkit.event.entity.ItemMergeEvent;
import org.bukkit.event.entity.ItemSpawnEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.Transformation;
import org.joml.Quaternionf;
import org.joml.Vector3f;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.UUID;

public final class CabecaGigantePlugin extends JavaPlugin implements Listener {
    private final Map<UUID, UUID> displaysByItem = new HashMap<>();
    private BukkitTask trackerTask;
    private double scale;
    private double yOffset;
    private long updateInterval;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        scale = Math.max(1.0, Math.min(8.0, getConfig().getDouble("scale", 3.0)));
        yOffset = getConfig().getDouble("y-offset", 0.08);
        updateInterval = Math.max(1L, getConfig().getLong("update-interval-ticks", 2L));
        getServer().getPluginManager().registerEvents(this, this);

        // Também cobre cabeças que já estavam no chão durante um /reload.
        for (World world : Bukkit.getWorlds()) {
            for (Entity entity : world.getEntities()) {
                if (entity instanceof Item item && isPlayerHead(item.getItemStack())) {
                    createDisplayLater(item);
                }
            }
        }

        trackerTask = Bukkit.getScheduler().runTaskTimer(this, this::updateDisplays, 1L, updateInterval);
        getLogger().info("CabecaGigante ativado (escala visual " + scale + "x).");
    }

    @Override
    public void onDisable() {
        if (trackerTask != null) trackerTask.cancel();
        for (UUID displayId : displaysByItem.values()) {
            Entity display = findEntity(displayId);
            if (display != null) display.remove();
        }
        displaysByItem.clear();
    }

    @EventHandler
    public void onItemSpawn(ItemSpawnEvent event) {
        if (isPlayerHead(event.getEntity().getItemStack())) {
            createDisplayLater(event.getEntity());
        }
    }

    @EventHandler
    public void onPickup(EntityPickupItemEvent event) {
        removeDisplayForItem(event.getItem().getUniqueId());
    }

    @EventHandler
    public void onDespawn(ItemDespawnEvent event) {
        removeDisplayForItem(event.getEntity().getUniqueId());
    }

    @EventHandler
    public void onMerge(ItemMergeEvent event) {
        // Se a cabeça for a entidade que vai desaparecer na fusão, remove seu modelo.
        removeDisplayForItem(event.getEntity().getUniqueId());
    }

    private boolean isPlayerHead(ItemStack stack) {
        return stack != null && stack.getType() == Material.PLAYER_HEAD;
    }

    private void createDisplayLater(Item item) {
        UUID itemId = item.getUniqueId();
        Bukkit.getScheduler().runTask(this, () -> {
            if (!item.isValid() || item.isDead() || !isPlayerHead(item.getItemStack())) return;
            if (displaysByItem.containsKey(itemId)) return;

            Location location = item.getLocation().clone().add(0, yOffset, 0);
            ItemDisplay display = item.getWorld().spawn(location, ItemDisplay.class, d -> {
                d.setItemStack(item.getItemStack().clone());
                d.setItemDisplayTransform(ItemDisplay.ItemDisplayTransform.FIXED);
                d.setBillboard(ItemDisplay.Billboard.FIXED);
                d.setTransformation(new Transformation(
                        new Vector3f(0f, 0f, 0f),
                        new Quaternionf(),
                        new Vector3f((float) scale, (float) scale, (float) scale),
                        new Quaternionf()
                ));
                d.setGravity(false);
                d.setInvulnerable(true);
                d.setSilent(true);
                d.setPersistent(false);
                d.setInterpolationDuration(1);
                d.setTeleportDuration(1);
                d.addScoreboardTag("cabecagigante_visual");
            });
            displaysByItem.put(itemId, display.getUniqueId());
        });
    }

    private void updateDisplays() {
        Iterator<Map.Entry<UUID, UUID>> iterator = displaysByItem.entrySet().iterator();
        while (iterator.hasNext()) {
            Map.Entry<UUID, UUID> entry = iterator.next();
            Entity itemEntity = findEntity(entry.getKey());
            Entity displayEntity = findEntity(entry.getValue());

            if (!(itemEntity instanceof Item item) || !item.isValid() || item.isDead()
                    || !isPlayerHead(item.getItemStack()) || !(displayEntity instanceof ItemDisplay display)
                    || !display.isValid()) {
                if (displayEntity != null) displayEntity.remove();
                iterator.remove();
                continue;
            }

            Location target = item.getLocation().clone().add(0, yOffset, 0);
            if (display.getWorld() != target.getWorld()
                    || display.getLocation().distanceSquared(target) > 0.0004) {
                display.teleport(target);
            }

            // Mantém a aparência correta se outro plugin atualizar o item dropado.
            if (!display.getItemStack().equals(item.getItemStack())) {
                display.setItemStack(item.getItemStack().clone());
            }
        }
    }

    private Entity findEntity(UUID id) {
        for (World world : Bukkit.getWorlds()) {
            Entity entity = world.getEntity(id);
            if (entity != null) return entity;
        }
        return null;
    }

    private void removeDisplayForItem(UUID itemId) {
        UUID displayId = displaysByItem.remove(itemId);
        if (displayId == null) return;
        Entity display = findEntity(displayId);
        if (display != null) display.remove();
    }
}
