# ZonaPUBG (Paper 1.21.11)

Plugin de zona circular estilo battle royale para Minecraft Java/Paper.

## Requisitos
- Java 21
- Maven
- Paper 1.21.11

## Compilar
Abra um terminal na pasta do projeto e execute:

```bash
mvn package
```

O arquivo será gerado em `target/ZonaPUBG-1.0.0.jar`.

## Instalar
1. Copie o JAR para a pasta `plugins` do servidor Paper.
2. Reinicie o servidor.
3. Edite `plugins/ZonaPUBG/config.yml` se quiser mudar os raios, tempos e dano.
4. Use `/zona iniciar`.

## Comandos
- `/zona iniciar`
- `/zona pausar`
- `/zona continuar`
- `/zona remover`
- `/zona status`

Permissão: `zonapubg.admin` (por padrão, operadores).

## Observações
- O sorteio de centro verifica terreno seco apenas em chunks já carregados, para evitar carregar/gerar grandes áreas automaticamente. Se não achar terreno seco, tente novamente ou ajuste a configuração.
- A zona é circular e visualizada com partículas; não usa a WorldBorder quadrada do Minecraft.
- Dano fora da zona é aplicado a cada segundo e cresce conforme a distância além da borda.

Configuração padrão atualizada para fases mais lentas, pausas maiores e círculo final de 20 blocos. Ajuste os tempos e raios em `plugins/ZonaPUBG/config.yml`.


## Raio inicial por comando
- `/zona raio 1500` define e salva o raio inicial para as próximas partidas.
- `/zona raio` mostra o raio configurado.
- `/zona iniciar 1500` inicia a zona imediatamente com raio inicial de 1500 blocos, sem alterar o valor salvo em config.
O valor permitido é de 20 a 100000 blocos.


## Morte súbita da zona final
Depois que a última fase chega ao raio de 20 blocos, o plugin aguarda 3 minutos. Se a partida ainda tiver mais de um jogador vivo, a zona fecha completamente, mostra o título vermelho **"Todos devem morrer!"** e passa a causar dano alto em qualquer lugar do mundo da zona. Quando resta apenas um jogador vivo (exceto espectadores), a zona para e anuncia o vencedor.
Ajustes em `config.yml`: `final-zone.wait-seconds` e `final-zone.damage-per-second`.
Os raios das fases agora são proporcionais ao raio inicial escolhido no comando.

Preferências: não anuncia o vencedor e não exibe aos jogadores a contagem regressiva dos 3 minutos da zona final. A mensagem de morte súbita continua aparecendo quando a zona fecha completamente.
