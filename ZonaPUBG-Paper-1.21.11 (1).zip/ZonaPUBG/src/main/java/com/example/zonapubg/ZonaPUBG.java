package com.example.zonapubg;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitTask;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Random;

public final class ZonaPUBG extends JavaPlugin implements CommandExecutor, TabCompleter {
    private final Random random = new Random();
    private final List<Phase> phases = new ArrayList<>();
    private World zoneWorld;
    private double centerX;
    private double centerZ;
    private double radius;
    private boolean active;
    private boolean paused;
    private boolean closing;
    private int phaseIndex;
    private int waitTicks;
    private int closeTicks;
    private int elapsedTicks;
    private double startX, startZ, startRadius;
    private double targetX, targetZ, targetRadius;
    private BukkitTask task;
    private long lastDamageTick;
    private double customInitialRadius;
    private int finalWaitTicks;
    private boolean suddenDeath;
    private boolean winnerDeclared;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        customInitialRadius = getConfig().getDouble("initial-radius", 2000);
        loadPhases();
        if (getCommand("zona") != null) {
            getCommand("zona").setExecutor(this);
            getCommand("zona").setTabCompleter(this);
        }
        getLogger().info("ZonaPUBG carregado. Use /zona iniciar.");
    }

    @Override
    public void onDisable() {
        stopTask();
    }

    private void loadPhases() {
        phases.clear();
        for (var section : getConfig().getMapList("phases")) {
            Object r = section.get("radius");
            Object w = section.get("wait-seconds");
            Object c = section.get("close-seconds");
            if (r instanceof Number radiusValue && w instanceof Number waitValue && c instanceof Number closeValue) {
                phases.add(new Phase(radiusValue.doubleValue(),
                        Math.max(0, waitValue.intValue()), Math.max(1, closeValue.intValue())));
            }
        }
        if (phases.isEmpty()) {
            phases.add(new Phase(1200, 90, 180));
            phases.add(new Phase(700, 60, 150));
            phases.add(new Phase(350, 45, 120));
            phases.add(new Phase(150, 30, 90));
            phases.add(new Phase(60, 20, 60));
            phases.add(new Phase(15, 15, 45));
        }
    }

    private void scalePhaseRadii(double initialRadius) {
        // As fases acompanham o raio escolhido no comando. A última fase regular termina em 20 blocos.
        double[] fractions = {0.75, 0.50, 0.30, 0.15, 0.07, 0.035, 0.02, 0.01};
        List<Phase> scaled = new ArrayList<>();
        int count = phases.size();
        for (int i = 0; i < count; i++) {
            Phase original = phases.get(i);
            double target;
            if (i == count - 1) {
                target = Math.min(20.0, initialRadius);
            } else {
                double fraction = fractions[Math.min(i, fractions.length - 1)];
                target = Math.max(20.0, Math.floor(initialRadius * fraction));
            }
            if (!scaled.isEmpty()) {
                target = Math.min(target, scaled.get(scaled.size() - 1).radius - 1);
            }
            target = Math.max(20.0, target);
            scaled.add(new Phase(target, original.waitSeconds, original.closeSeconds));
        }
        phases.clear();
        phases.addAll(scaled);
    }

    private String msg(String message) {
        String prefix = getConfig().getString("messages.prefix", "&8[&bZona&8] &r");
        return color(prefix + message);
    }

    private String color(String text) {
        return ChatColor.translateAlternateColorCodes('&', text);
    }

    private void broadcast(String message) {
        Bukkit.broadcastMessage(msg(message));
    }

    private void startZone(CommandSender sender) {
        if (active) {
            sender.sendMessage(msg("&eA zona já está ativa. Use /zona remover antes de iniciar outra."));
            return;
        }
        String worldName = getConfig().getString("world", "").trim();
        if (worldName.isEmpty()) {
            zoneWorld = Bukkit.getWorlds().isEmpty() ? null : Bukkit.getWorlds().get(0);
        } else {
            zoneWorld = Bukkit.getWorld(worldName);
        }
        if (zoneWorld == null) {
            sender.sendMessage(msg("&cNão encontrei o mundo configurado. Confira world no config.yml."));
            return;
        }

        double initialRadius = Math.max(20, customInitialRadius);
        Location spawn = zoneWorld.getSpawnLocation();
        Location center = findDryLocation(zoneWorld, spawn.getX(), spawn.getZ(),
                Math.max(100, getConfig().getDouble("center-search-radius", 1500)), 40);
        if (center == null) {
            sender.sendMessage(msg("&cNão consegui encontrar terreno seco. Tente novamente ou ajuste a configuração."));
            return;
        }

        centerX = center.getX();
        centerZ = center.getZ();
        radius = initialRadius;
        scalePhaseRadii(initialRadius);
        phaseIndex = 0;
        active = true;
        paused = false;
        closing = false;
        suddenDeath = false;
        winnerDeclared = false;
        finalWaitTicks = 0;
        waitTicks = 0;
        closeTicks = 0;
        elapsedTicks = 0;
        lastDamageTick = 0;
        broadcast("&aA zona começou! &fCentro inicial: &b" + (int) centerX + ", " + (int) centerZ
                + " &f| Raio: &b" + (int) radius + " blocos.");
        stopTask();
        task = Bukkit.getScheduler().runTaskTimer(this, this::tickZone, 1L, 1L);
    }

    private Location findDryLocation(World world, double aroundX, double aroundZ, double searchRadius, int attempts) {
        for (int i = 0; i < attempts; i++) {
            double x = aroundX + (random.nextDouble() * 2 - 1) * searchRadius;
            double z = aroundZ + (random.nextDouble() * 2 - 1) * searchRadius;
            int bx = (int) Math.floor(x);
            int bz = (int) Math.floor(z);
            // Carrega o chunk escolhido para poder verificar o terreno.
            // O número de tentativas é limitado para evitar buscas longas.
            world.getChunkAt(bx >> 4, bz >> 4);
            int y = world.getHighestBlockYAt(bx, bz);
            Block ground = world.getBlockAt(bx, y, bz);
            Block feet = world.getBlockAt(bx, y + 1, bz);
            Block head = world.getBlockAt(bx, y + 2, bz);
            if (ground.getType().isAir() || isLiquid(ground.getType())
                    || isLiquid(feet.getType()) || isLiquid(head.getType())
                    || !feet.getType().isAir() || !head.getType().isAir()) {
                continue;
            }
            return new Location(world, bx + 0.5, y + 1, bz + 0.5);
        }
        return null;
    }

    private boolean isLiquid(Material material) {
        return material == Material.WATER || material == Material.LAVA;
    }

    private void tickZone() {
        if (!active || paused || zoneWorld == null) return;

        if (closing) {
            elapsedTicks++;
            double progress = Math.min(1.0, (double) elapsedTicks / Math.max(1, closeTicks));
            centerX = lerp(startX, targetX, progress);
            centerZ = lerp(startZ, targetZ, progress);
            radius = lerp(startRadius, targetRadius, progress);
            if (progress >= 1.0) {
                closing = false;
                phaseIndex++;
                waitTicks = 0;
                elapsedTicks = 0;
                broadcast("&aFase " + phaseIndex + " concluída! &fRaio atual: &b" + (int) radius + " blocos.");
                // A contagem final acontece em silêncio, sem aviso aos jogadores.
            }
        } else if (phaseIndex < phases.size()) {
            Phase next = phases.get(phaseIndex);
            waitTicks++;
            if (waitTicks >= next.waitSeconds * 20) {
                beginClosing(next);
            }
        } else if (!suddenDeath) {
            finalWaitTicks++;
            int waitForFinal = Math.max(1, getConfig().getInt("final-zone.wait-seconds", 180)) * 20;
            if (finalWaitTicks >= waitForFinal) {
                startSuddenDeath();
            }
        }

        // Checa o vencedor antes de aplicar qualquer dano; o último sobrevivente nunca recebe dano da zona.
        checkForWinner();
        if (!active) return;

        if (getConfig().getBoolean("visual.enabled", true)
                && Bukkit.getCurrentTick() % Math.max(1, getConfig().getInt("visual.update-ticks", 20)) == 0) {
            if (radius > 0.5) drawRing();
        }

        if (getConfig().getBoolean("damage.enabled", true)
                && Bukkit.getCurrentTick() - lastDamageTick >= 20) {
            lastDamageTick = Bukkit.getCurrentTick();
            if (suddenDeath) {
                applySuddenDeathDamage();
            } else {
                applyDamage();
            }
        }
    }

    private void startSuddenDeath() {
        suddenDeath = true;
        radius = 0;
        targetRadius = 0;
        closing = false;
        broadcast("&c&lTODOS DEVEM MORRER! &fA zona fechou completamente!");
        for (Player player : zoneWorld.getPlayers()) {
            player.sendTitle(ChatColor.RED + "" + ChatColor.BOLD + "Todos devem morrer!", "",
                    10, 100, 20);
        }
    }

    private void applySuddenDeathDamage() {
        double damage = Math.max(1.0, getConfig().getDouble("final-zone.damage-per-second", 10.0));
        for (Player player : zoneWorld.getPlayers()) {
            if (isAliveParticipant(player)) {
                player.damage(damage);
            }
        }
    }

    private boolean isAliveParticipant(Player player) {
        return player.isOnline()
                && !player.isDead()
                && player.getGameMode() != org.bukkit.GameMode.SPECTATOR;
    }

    private void checkForWinner() {
        if (!active || zoneWorld == null || winnerDeclared) return;
        List<Player> alive = new ArrayList<>();
        for (Player player : zoneWorld.getPlayers()) {
            if (isAliveParticipant(player)) alive.add(player);
        }
        if (alive.size() == 1) {
            winnerDeclared = true;
            active = false;
            paused = false;
            stopTask();
            // A partida termina silenciosamente; não anuncia o vencedor no chat.
        }
    }

    private void beginClosing(Phase phase) {
        // Sorteia o próximo centro dentro do círculo atual, com margem para o círculo novo caber nele.
        double maxOffset = Math.max(0, radius - phase.radius) * 0.65;
        Location nextCenter = findDryLocation(zoneWorld, centerX, centerZ, maxOffset, 100);
        if (nextCenter == null) {
            // Se não houver chunks carregados com terra, mantém o centro atual.
            targetX = centerX;
            targetZ = centerZ;
        } else {
            targetX = nextCenter.getX();
            targetZ = nextCenter.getZ();
        }
        startX = centerX;
        startZ = centerZ;
        startRadius = radius;
        targetRadius = Math.min(radius, phase.radius);
        closeTicks = phase.closeSeconds * 20;
        elapsedTicks = 0;
        closing = true;
        broadcast("&eFase " + (phaseIndex + 1) + " começou! &fA zona vai fechar para &b"
                + (int) targetRadius + " blocos &fem aproximadamente &b" + phase.closeSeconds + "s&f.");
    }

    private double lerp(double a, double b, double t) {
        return a + (b - a) * t;
    }

    private void drawRing() {
        Particle particle;
        try {
            particle = Particle.valueOf(getConfig().getString("visual.particle", "END_ROD").toUpperCase(Locale.ROOT));
        } catch (IllegalArgumentException ex) {
            particle = Particle.END_ROD;
        }
        int points = Math.max(24, getConfig().getInt("visual.points", 90));
        for (int i = 0; i < points; i++) {
            double angle = (Math.PI * 2 * i) / points;
            double x = centerX + Math.cos(angle) * radius;
            double z = centerZ + Math.sin(angle) * radius;
            int bx = (int) Math.floor(x);
            int bz = (int) Math.floor(z);
            if (!zoneWorld.isChunkLoaded(bx >> 4, bz >> 4)) continue;
            int y = zoneWorld.getHighestBlockYAt(bx, bz) + 1;
            zoneWorld.spawnParticle(particle, x, y, z, 1, 0, 0.1, 0, 0);
        }
    }

    private void applyDamage() {
        double base = Math.max(0, getConfig().getDouble("damage.base", 1.0));
        double step = Math.max(1, getConfig().getDouble("damage.increase-per-blocks", 10.0));
        double max = Math.max(base, getConfig().getDouble("damage.maximum", 8.0));
        for (Player player : zoneWorld.getPlayers()) {
            Location loc = player.getLocation();
            double dx = loc.getX() - centerX;
            double dz = loc.getZ() - centerZ;
            double distance = Math.sqrt(dx * dx + dz * dz);
            double outside = distance - radius;
            if (outside > 0) {
                double damage = Math.min(max, base + (outside / step));
                player.damage(damage);
                if (outside > 20 && player.getTicksLived() % 100 < 20) {
                    player.sendActionBar(color("&cVocê está fora da zona! Distância: " + (int) outside + " blocos."));
                }
            }
        }
    }

    private void pauseZone(CommandSender sender) {
        if (!active) {
            sender.sendMessage(msg("&cNão existe zona ativa."));
            return;
        }
        if (paused) {
            sender.sendMessage(msg("&eA zona já está pausada."));
            return;
        }
        paused = true;
        broadcast("&eA zona foi pausada.");
    }

    private void resumeZone(CommandSender sender) {
        if (!active) {
            sender.sendMessage(msg("&cNão existe zona ativa."));
            return;
        }
        if (!paused) {
            sender.sendMessage(msg("&eA zona não está pausada."));
            return;
        }
        paused = false;
        broadcast("&aA zona voltou a funcionar.");
    }

    private void removeZone(CommandSender sender) {
        if (!active) {
            sender.sendMessage(msg("&cNão existe zona ativa."));
            return;
        }
        active = false;
        paused = false;
        closing = false;
        stopTask();
        broadcast("&cA zona foi removida por um administrador.");
    }

    private void stopTask() {
        if (task != null) {
            task.cancel();
            task = null;
        }
    }

    private void sendStatus(CommandSender sender) {
        if (!active) {
            sender.sendMessage(msg("&eNenhuma zona ativa."));
            return;
        }
        String state = paused ? "&ePausada" : suddenDeath ? "&cMorte súbita" : closing ? "&6Fechando fase " + (phaseIndex + 1) : phaseIndex >= phases.size() ? "&cContagem para morte súbita" : "&aAguardando fase " + (phaseIndex + 1);
        sender.sendMessage(msg("&fEstado: " + state + " &f| Raio: &b" + (int) radius
                + " &f| Centro: &b" + (int) centerX + ", " + (int) centerZ));
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("zonapubg.admin")) {
            sender.sendMessage(msg("&cVocê não tem permissão para isso."));
            return true;
        }
        if (args.length == 0) {
            sender.sendMessage(msg("&fUse: &b/zona iniciar [raio], raio <blocos>, pausar, continuar, remover ou status"));
            return true;
        }
        switch (args[0].toLowerCase(Locale.ROOT)) {
            case "iniciar" -> {
                if (args.length >= 2) {
                    Double value = parseRadius(args[1]);
                    if (value == null) {
                        sender.sendMessage(msg("&cInforme um raio válido em blocos, por exemplo: /zona iniciar 1500"));
                        return true;
                    }
                    customInitialRadius = value;
                }
                startZone(sender);
            }
            case "raio" -> {
                if (args.length < 2) {
                    sender.sendMessage(msg("&fRaio inicial configurado: &b" + (int) customInitialRadius
                            + " blocos&f. Use &b/zona raio <blocos>&f para alterar."));
                    return true;
                }
                Double value = parseRadius(args[1]);
                if (value == null) {
                    sender.sendMessage(msg("&cInforme um raio válido entre 20 e 100000 blocos."));
                    return true;
                }
                customInitialRadius = value;
                getConfig().set("initial-radius", value);
                saveConfig();
                sender.sendMessage(msg("&aRaio inicial definido para &b" + (int) value
                        + " blocos&a. Será usado na próxima zona."));
            }
            case "pausar" -> pauseZone(sender);
            case "continuar", "retomar" -> resumeZone(sender);
            case "remover", "parar" -> removeZone(sender);
            case "status" -> sendStatus(sender);
            default -> sender.sendMessage(msg("&fUse: &b/zona iniciar [raio], raio <blocos>, pausar, continuar, remover ou status"));
        }
        return true;
    }

    private Double parseRadius(String input) {
        try {
            double value = Double.parseDouble(input);
            if (!Double.isFinite(value) || value < 20 || value > 100000) return null;
            return value;
        } catch (NumberFormatException ex) {
            return null;
        }
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) {
            List<String> options = List.of("iniciar", "raio", "pausar", "continuar", "remover", "status");
            String prefix = args[0].toLowerCase(Locale.ROOT);
            List<String> matches = new ArrayList<>();
            for (String option : options) if (option.startsWith(prefix)) matches.add(option);
            return matches;
        }
        return Collections.emptyList();
    }

    private record Phase(double radius, int waitSeconds, int closeSeconds) {}
}
